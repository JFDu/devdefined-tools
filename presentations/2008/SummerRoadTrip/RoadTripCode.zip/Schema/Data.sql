set IDENTITY_INSERT [Event] ON

insert into [Event](Id, Name, Location, LocationName, EventTime) values( 1, 'Auckland', 'POINT(-36.8486667 174.7621833)', 'Auckland Institute of Technology', '4 Feb 2008 13:00:00' )
insert into [Event](Id, Name, Location, LocationName, EventTime) values( 2, 'Tauranga', 'POINT(-37.669540 176.152840)', 'Bureta Park Motor Inn', '5 Feb 2008 13:00:00' )
insert into [Event](Id, Name, Location, LocationName, EventTime) values( 3, 'Hamilton', 'POINT(-37.793295 175.282413)', 'Wintec', '7 Feb 2008 13:00:00' )
insert into [Event](Id, Name, Location, LocationName, EventTime) values( 4, 'New Plymouth', 'POINT(-39.058034 174.076331)', 'Quality Hotel Plymouth International', '8 Feb 2008 13:00:00' )
insert into [Event](Id, Name, Location, LocationName, EventTime) values( 5, 'Hawkes Bay', 'POINT(-39.47885 176.897076)', 'East Pier', '11 Feb 2008 13:00:00' )
insert into [Event](Id, Name, Location, LocationName, EventTime) values( 6, 'Palmerston North', 'POINT(-40.357541 175.613354)', 'Palmerston North Convention Centre', '12 Feb 2008 13:00:00' )
insert into [Event](Id, Name, Location, LocationName, EventTime) values( 7, 'Wellington', 'POINT(-41.294003 174.782175)', 'Paramount Cinema', '13 Feb 2008 13:00:00' )
insert into [Event](Id, Name, Location, LocationName, EventTime) values( 8, 'Nelson', 'POINT(-41.281015 173.246745)', 'Tahuna Beach Function Rooms', '14 Feb 2008 13:00:00' )
insert into [Event](Id, Name, Location, LocationName, EventTime) values( 9, 'Christchurch', 'POINT(-43.526958 172.635072)', 'Christchurch Convention Centre', '15 Feb 2008 13:00:00' )
insert into [Event](Id, Name, Location, LocationName, EventTime) values( 10, 'Dunedin', 'POINT(-45.874086 170.503653)', 'Dunedin Town Hall', '18 Feb 2008 13:00:00' )
insert into [Event](Id, Name, Location, LocationName, EventTime) values( 11, 'Invercargill', 'POINT(-46.41289 168.359985)', 'Ascot Park Hotel', '19 Feb 2008 13:00:00' )


set IDENTITY_INSERT [Event] OFF

set IDENTITY_INSERT Member ON

insert into Member(Id, Name, EmailAddress, CookieKey) values( 1, 'Jeremy Boyd', 'jeremy@mindscape.co.nz', null )
insert into Member(Id, Name, EmailAddress, CookieKey) values( 2, 'Chris Auld', 'chris@intergen.co.nz', null )

set IDENTITY_INSERT Member OFF

set IDENTITY_INSERT BlogPost ON

insert into BlogPost(Id, MemberId, PhotoId, Subject, Body, PostedOn) values (1, 1, 1, 'Welcome to the Summer Road Trip', 'This is a test post', getdate() )
insert into BlogPost(Id, MemberId, PhotoId, Subject, Body, PostedOn) values (2, 1, 2, '.NET 3.5 Rocks!', 'This is a test post', getdate() )
insert into BlogPost(Id, MemberId, PhotoId, Subject, Body, PostedOn) values (3, 1, 3, 'Do more with Visual Studio 2008', 'This is a test post', getdate() )
insert into BlogPost(Id, MemberId, PhotoId, Subject, Body, PostedOn) values (4, 2, 1, 'Your data any time any place with SQL Server 2008', 'This is a test post', getdate() )
insert into BlogPost(Id, MemberId, PhotoId, Subject, Body, PostedOn) values (5, 2, 4, 'Check out Hyper-V on Windows Server 2008', 'This is a test post', getdate() )

set IDENTITY_INSERT BlogPost OFF

insert into BlogComment(MemberId, BlogPostId, Subject, Body, PostedOn) values(2, 1, 'Cant wait..', 'Until we get to that 7m waterfall in Rotorua :)', getdate() )

insert into EventMember values(1, 1)
insert into EventMember values(1, 2)