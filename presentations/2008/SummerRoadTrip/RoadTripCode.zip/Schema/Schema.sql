IF  EXISTS (SELECT name FROM sys.databases WHERE name = N'SummerRoadTrip')
DROP DATABASE [SummerRoadTrip]
GO

DECLARE @device_directory NVARCHAR(520)
SELECT @device_directory = SUBSTRING(filename, 1, CHARINDEX(N'master.mdf', LOWER(filename)) - 1)
FROM master.dbo.sysaltfiles WHERE dbid = 1 AND fileid = 1

EXECUTE (N'CREATE DATABASE [SummerRoadTrip] ON  PRIMARY 
( NAME = N''SummerRoadTrip'', FILENAME = N''' + @device_directory + N'SummerRoadTrip.mdf'' , SIZE = 8192KB , MAXSIZE = UNLIMITED, FILEGROWTH = 1024KB ),
FILEGROUP FileStreamGroup1 CONTAINS FILESTREAM
( NAME = PhotoFileStreams, FILENAME = N''C:\FSData\PhotoFileStreams'')
LOG ON 
( NAME = N''SummerRoadTrip_log'', FILENAME = N''' + @device_directory + N'SummerRoadTrip_log.ldf'' , SIZE = 1024KB , MAXSIZE = 2048GB , FILEGROWTH = 10%)')

GO

IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = N'RoadTripUser')
CREATE LOGIN [RoadTripUser] WITH PASSWORD=N'�����о?^(?O*�=?��E�*#|�v?', DEFAULT_DATABASE=[SummerRoadTrip], DEFAULT_LANGUAGE=[us_english], CHECK_EXPIRATION=OFF, CHECK_POLICY=OFF
GO

USE SummerRoadTrip
GO

CREATE USER [RoadTripUser] FOR LOGIN [RoadTripUser] WITH DEFAULT_SCHEMA=[dbo]
GO

EXEC sp_addrolemember N'db_owner', N'RoadTripUser'
GO

CREATE TABLE [Photo]
(
  Id int NOT NULL PRIMARY KEY IDENTITY(1, 1),
  Name varchar(255) NOT NULL,
  Data varbinary(max) FILESTREAM,
  Location geography,
  RowGuid UNIQUEIDENTIFIER ROWGUIDCOL NOT NULL UNIQUE
)


CREATE TABLE [Member]
(
  Id int IDENTITY(1,1) NOT NULL PRIMARY KEY,
  Name varchar(100) NOT NULL,
  EmailAddress varchar(255) NOT NULL,
  CookieKey varchar(50) NULL
)

CREATE TABLE [BlogPost]
(
  Id int IDENTITY(1,1) NOT NULL PRIMARY KEY,
  MemberId int NOT NULL REFERENCES Member(Id),
  PhotoId int,
  Subject varchar(100) NOT NULL,
  Body varchar(max) NOT NULL,
  PostedOn datetime
)
GO

ALTER TABLE [dbo].[BlogPost]  WITH CHECK ADD CONSTRAINT [FK__BlogPost_IPhoto] FOREIGN KEY([PhotoId])
REFERENCES [dbo].[Photo] ([Id])
GO

CREATE TABLE [BlogComment]
(
  Id int IDENTITY(1,1) NOT NULL PRIMARY KEY,
  MemberId int NOT NULL REFERENCES Member(Id),
  BlogPostId int NOT NULL REFERENCES BlogPost(Id),
  Subject varchar(100) NOT NULL,
  Body varchar(max) NOT NULL,
  PostedOn datetime
)


CREATE TABLE [Event]
(
  Id int IDENTITY(1,1) NOT NULL PRIMARY KEY,
  Name varchar(100) NOT NULL,
  Location geography NOT NULL,
  LocationName varchar(100) NOT NULL,
  EventTime datetime
)


CREATE TABLE [EventMember]
(
  Id int IDENTITY(1,1) NOT NULL PRIMARY KEY,  
  EventId int NOT NULL REFERENCES Event(Id),
  MemberId int NOT NULL REFERENCES Member(Id)
)

go