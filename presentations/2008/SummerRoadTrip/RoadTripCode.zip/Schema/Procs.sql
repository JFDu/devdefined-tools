create procedure dbo.BlogPost_GetBySpatialIntersection
(
@circle geography
)
as
begin

select BlogPost.* from BlogPost
	inner join Photo on BlogPost.PhotoId = Photo.Id
	where Photo.Location.STIntersects(@circle) = 1

end
go

create procedure dbo.Photo_GetBySpatialIntersection
(
@circle geography
)
as
begin

select * from Photo	
	where Location.STIntersects(@circle) = 1

end
go

create procedure Photo_Insert
(
@Name varchar(255),
@Data varbinary(max),
@Location varchar(255)
)
as
begin

	insert into Photo( Name, Data, Location, RowGuid )
		values ( @Name, @Data, @Location, newid() )

	select @@identity

end