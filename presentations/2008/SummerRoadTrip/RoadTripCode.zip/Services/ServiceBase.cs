﻿using System;
using System.Configuration;
using System.Diagnostics.CodeAnalysis;

namespace SummerRoadTrip.Services
{
  /// <summary>
  /// Provides a common set of base functionality for all services
  /// </summary>
  [SuppressMessage("Microsoft.Design", "CA1063:ImplementIDisposableCorrectly")]
  public class ServiceBase : IDisposable
  {
    private readonly Model.Entities _context;

    public ServiceBase()
    {
      // Instantiate the Entities context object based on a supplied connection string
      _context = new Model.Entities(ConfigurationManager.ConnectionStrings["Entities"].ConnectionString);
    }

    protected Model.Entities EntityContext
    {
      get { return _context; }
    }

    /// <summary>
    /// Persists all model changes back to our store
    /// </summary>
    /// <remarks>
    /// This method simply calls the SaveChanges method exposed by the Entities context object. This instructs the Entity
    /// Framework to save any changed entities which it is currently tracking
    /// </remarks>
    internal void SaveChanges()
    {
      _context.SaveChanges();
    }

    #region IDisposable Members

    public void Dispose()
    {
      if (_context != null)
      {
        _context.SaveChanges();
        _context.Dispose();
      }

      GC.SuppressFinalize(this);
    }

    #endregion
  }
}
