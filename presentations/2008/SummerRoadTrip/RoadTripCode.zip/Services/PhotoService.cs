﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using SummerRoadTrip.Services.Contracts;
using SummerRoadTrip.Model;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace SummerRoadTrip.Services
{
  public sealed class PhotoService : ServiceBase, IPhotoService
  {
    /// <summary>
    /// Returns a specific photo identified by its unique id
    /// </summary>
    /// <param name="id">The unique id of the photo to be returned</param>
    public Photo GetPhoto(int id)
    {
      try
      {
        Photo photo = EntityContext.Photo.First(p => p.Id == id);

        // The location property needs to be handled specially because there is no direct support for handling UDT's
        // in the Entities framework and additionally we are using Well Known Text locally. This helper function 
        // will use an additional call back to SQL Server to select out the location column for this event and return it 
        // as Well Known Text (WKT)
        photo.Location = SpatialHelper.SelectWKTForEntityColumn(typeof(Photo), "Location", photo.Id);

        // The data property needs to be handled specially because we want to read this data using the the Win32 API's
        // available for this FILESTREAM based column. In a normal situation we would probably leverage the Entity
        // Framework to read and write this data directly, however the benefit of the Win32 based access is that we
        // can read the data in on demand in a more performant manner, so for the purposes of demonstration we are
        // using this approach in our system
        photo.Data = FileStreamHelper.GetDataFromFileStream(typeof(Photo), "Data", photo.Id);

        return photo;
      }
      catch (InvalidOperationException)
      {
        return null;
      }      
    }

    /// <summary>
    /// Adds a new Photo to the system
    /// </summary>
    /// <remarks>
    /// Because we are not retrieving either the Data or Location properties natively using the Entity Framework, it 
    /// is largely pointless for us to use the Entity Context to add a new object. Rather we are inserting new photos
    /// the old fashioned way using ADO.NET and a stored procedure
    /// 
    /// NOTE: It is not recommended to use this approach in a standard system - this is a side effect of our decisions to
    /// handle the Data and Location properties in a fashion which is not directly compatible with the Entity Framework
    /// </remarks>
    public int Add(string name, byte[] data, string location)
    {
      int id;

      // In an ideal work, this would be something like:
      //    EntityContext.Photo_Insert(photo.Name, photo.Data, photo.Location);
      // However Entities doesnt support stored procs with null return types yet
      //
      // Alternatively we might like to type:
      //    EntityContext.AddToPhoto(photo)
      // However because of the lack of UDT support this currently wont work too well either

      // TODO: Find a better way of doing this, or wait until the above can be supported :)
      using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["Database"].ConnectionString))
      {
        connection.Open();

        using (SqlCommand command = new SqlCommand())
        {
          command.CommandType = CommandType.StoredProcedure;
          command.CommandText = "Photo_Insert";

          command.Parameters.AddWithValue("@Name", name);
          command.Parameters.AddWithValue("@Data", data);
          command.Parameters.AddWithValue("@Location", location);

          command.Connection = connection;

          id = int.Parse(command.ExecuteScalar().ToString(), CultureInfo.InvariantCulture);
        }

        connection.Close();
      }

      return id;      
    }

    /// <summary>
    /// Returns a collection of all Photos registered with the system
    /// </summary>
    public List<Photo> GetAllPhotos()
    {
      List<Photo> photos = new List<Photo>();

      foreach (Photo photo in EntityContext.Photo)
      {
        // The location property needs to be handled specially - refer to the GetPhoto method above for more detail
        photo.Location = SpatialHelper.SelectWKTForEntityColumn(typeof(Photo), "Location", photo.Id);

        // The data property needs to be handled specially - refer to the GetPhoto method above for more detail
        photo.Data = FileStreamHelper.GetDataFromFileStream(typeof(Photo), "Data", photo.Id);

        photos.Add(photo);
      }

      return photos;
    }

    /// <summary>
    /// Returns a collection of random photos, with the maximum being bounded by the supplied number
    /// </summary>
    /// <param name="number">The maximum number of photos to be returned</param>
    /// <remarks>
    /// For this method, we simply return all photos and then remove a random selection until we reach the upper
    /// bound of the requested set
    /// </remarks>
    public List<Photo> GetRandomPhotos(int number)
    {
      List<Photo> photos = GetAllPhotos();

      while (photos.Count > number)
      {
        photos.RemoveAt(new Random().Next(0, photos.Count - 1));
      }

      return photos;
    }

    /// <summary>
    /// Returns a collection of photos which are spatially located within the bounds of the circle which is decribed by the
    /// passed latitude, longitude and radius parameters
    /// </summary>
    /// <param name="latitude">The latitude of the center of the circle</param>
    /// <param name="longitude">The longitude of the center of the circle</param>
    /// <param name="radius">The radius of the circle</param>
    /// <remarks>
    /// For this function, we are excuting the BlogPost_GetBySpatialIntersection blog post by calling to it through 
    /// the imported function/method on the Entities context object. The stored procedure takes a geometry data type parameter
    /// which is implicitly converted from a string formatted in the Well Known Text (WKT) format which we construct from the
    /// call to SpatialHelper.GetCircleWKT
    /// </remarks>
    public List<Photo> GetByLocation(double latitude, double longitude, double radius)
    {
      return new List<Photo>(
        EntityContext.Photo_GetBySpatialIntersection(
          SpatialHelper.GetCircleWKT(latitude, longitude, (radius * Constants.MilesToKilometers) / Constants.OneDegreeInKilometers, Constants.NumberOfPointsForCircles)
          )
        );
    }
  }
}
