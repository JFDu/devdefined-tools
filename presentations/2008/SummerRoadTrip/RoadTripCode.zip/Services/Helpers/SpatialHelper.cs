﻿using System;
using System.Text;
using System.Diagnostics.CodeAnalysis;
using System.Data.SqlClient;
using System.Configuration;
using System.Globalization;

namespace SummerRoadTrip.Services
{
  internal static class SpatialHelper
  {
    internal static string SelectWKTForEntityColumn(Type entityType, string property, int id)
    {
      SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["Database"].ConnectionString);
      connection.Open();

      using (SqlCommand command = new SqlCommand(String.Format(CultureInfo.CurrentCulture, "select CONVERT(varchar(max), {0}) from {1} where Id = @Id", property, entityType.Name), connection))
      {
        command.Parameters.Add(new SqlParameter("@Id", id));

        string wkt = command.ExecuteScalar().ToString();

        connection.Close();
        connection.Dispose();

        return wkt;
      }      
    }

    /// <summary>
    /// Generates a WKT string containing a POLYGON which represents a rough circle around the origin X,Y with a specific radius and
    /// number of points of precision along the rim
    /// </summary>
    [SuppressMessage("Microsoft.Naming", "CA1704:IdentifiersShouldBeSpelledCorrectly", MessageId = "Y"), SuppressMessage("Microsoft.Naming", "CA1704:IdentifiersShouldBeSpelledCorrectly", MessageId = "X"), SuppressMessage("Microsoft.Naming", "CA1709:IdentifiersShouldBeCasedCorrectly", MessageId = "WKT"), SuppressMessage("Microsoft.Naming", "CA1709:IdentifiersShouldBeCasedCorrectly", MessageId = "Y"), SuppressMessage("Microsoft.Naming", "CA1709:IdentifiersShouldBeCasedCorrectly", MessageId = "X")]
    internal static string GetCircleWKT(double X, double Y, double radius, int points)
    {
      StringBuilder wkt = new StringBuilder( "POLYGON ((" );

      if (points < 4) points = 4;

      double[] x = new double[points];
      double[] y = new double[points];

      double unit = 2 * Math.PI / points;

      for (int i = 0; i < points; i++)
      {
        x[i] = X + radius * Math.Sin(unit * i);
        y[i] = Y + radius * Math.Cos(unit * i);
        
        wkt.AppendFormat( "{0} {1}, ", Math.Round(x[i], 4), Math.Round(y[i], 4) );
      }

      // re-append the origin co-ordinates
      wkt.AppendFormat("{0} {1}))", Math.Round(x[0], 4), Math.Round(y[0], 4));

      return wkt.ToString();
    }

    /// <summary>
    /// Returns the origin points for a POLYGON WKT string which represents a circle, it is assumed that the circle
    /// will have been defined as in GetCircleWKT()
    /// </summary>
    internal static double[] GetOriginFromCircleWKT(string wkt, double radius)
    {
      if ( String.IsNullOrEmpty( wkt ) ) throw new ArgumentException( "Null or Empty Well Known Text" );
      if (wkt.IndexOf("((", StringComparison.OrdinalIgnoreCase) < 0 || wkt.IndexOf("))", StringComparison.OrdinalIgnoreCase) < 0) throw new ArgumentException("Invalid Well Known Text");

      string[] parts = wkt.Substring(wkt.IndexOf("((", StringComparison.OrdinalIgnoreCase) + 2).Replace("))", String.Empty).Split(',');
      string[] coords = parts[0].Split(' ');

      try
      {
        double[] origin = new double[2];
        origin[0] = double.Parse(coords[0], CultureInfo.CurrentCulture);
        origin[1] = double.Parse(coords[1], CultureInfo.CurrentCulture) - radius;

        return origin;
      }
      catch (FormatException)
      {
        return null;
      }
    }
  }
}
