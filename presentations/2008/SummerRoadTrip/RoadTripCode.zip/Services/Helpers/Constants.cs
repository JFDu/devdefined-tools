﻿
namespace SummerRoadTrip.Services
{
  public static class Constants
  {
    public const int NumberOfPointsForCircles = 10;
    public const double OneDegreeInKilometers = 111.2;
    public const double MilesToKilometers = 1.609344;
  }
}
