﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.IO;
using System.Runtime.InteropServices;
using Microsoft.Win32.SafeHandles;

namespace SummerRoadTrip.Services
{
  internal static class FileStreamHelper
  {
    public const UInt32 DESIRED_ACCESS_READ = 0x00000000;  
    public const UInt32 DESIRED_ACCESS_WRITE = 0x00000001;  
    public const UInt32 DESIRED_ACCESS_READWRITE = 0x00000002;

    [DllImport("sqlncli10.dll", SetLastError = true, CharSet = CharSet.Unicode)]
    private extern static IntPtr OpenSqlFilestream(
        string path,
        int access,
        int openOptions,
        byte[] txnContext,
        int contextLength,
        ref int allocationSize);

    internal static byte[] GetDataFromFileStream(Type entityType, string property, int id)
    {
      SqlTransaction transaction = null;

      try
      {
        SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["Database"].ConnectionString);

        connection.Open();

        using (SqlCommand command = new SqlCommand(String.Format(CultureInfo.CurrentCulture, "select {0}.PathName() as PathName, GET_FILESTREAM_TRANSACTION_CONTEXT() as TransCtx from {1} where Id = @Id", property, entityType.Name), connection))
        {
          transaction = connection.BeginTransaction();

          command.Parameters.Add(new SqlParameter("@Id", id));
          command.Transaction = transaction;

          SqlDataReader reader = command.ExecuteReader(CommandBehavior.SingleRow);
          
          byte[] data;

          reader.Read();

          string pathname = reader["PathName"].ToString();

          byte[] bits = ((byte[])(reader["TransCtx"]));
          int len = bits.Length;
          int allocSize = 0;

          reader.Close();

          if (String.IsNullOrEmpty(pathname))
          {
            return null;
          }

          IntPtr handle = OpenSqlFilestream(
                            pathname,
                            0,
                            0,
                            bits,
                            len,
                            ref allocSize
                            );

          SafeFileHandle safeHandle = new SafeFileHandle(handle, true);

          if ( safeHandle.IsInvalid )
          {
            Marshal.ThrowExceptionForHR(Marshal.GetHRForLastWin32Error());
          }

          using (FileStream fs = new FileStream(safeHandle, FileAccess.Read))
          {
            data = new byte[fs.Length];
            fs.Read(data, 0, (int)fs.Length);
            fs.Close();
          }

          transaction.Rollback();

          connection.Close();
          connection.Dispose();

          return data;
        }
      }
      catch (SqlException)
      {
        if ( transaction != null ) transaction.Rollback();
        return null;
      }
      catch (ArgumentException)
      {
        if (transaction != null) transaction.Rollback();
        return null;
      }
    }
  }
}
