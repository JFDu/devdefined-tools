﻿using System;
using System.Linq;
using System.Collections.Generic;
using SummerRoadTrip.Model;
using SummerRoadTrip.Services.Contracts;

namespace SummerRoadTrip.Services
{
  public sealed class BlogService : ServiceBase, IBlogService
  {
    /// <summary>
    /// Adds a new blog post into the system
    /// </summary>
    /// <remarks>
    /// We are simply instantiating a new BlogPost object and populating its properties in this method
    /// We need to refetch the associated member and photo's for the BlogPost to ensure they are scoped
    /// within the same context as the newly added post.
    /// </remarks>
    public int Add(string subject, string body, int memberId, int? photoId)
    {
      BlogPost post = new BlogPost();

      post.Subject = subject;
      post.Body = body;
      post.PostedOn = DateTime.Now;

      try
      {
        post.Member = EntityContext.Member.First(m => m.Id == memberId);
      }
      catch (InvalidOperationException)
      {
        // This exception is thrown when no data is present
      }

      if (post.Member == null)
      {
        throw new ArgumentNullException("A valid member must be associated as the author of this post");
      }

      if (photoId != null)
      {
        try
        {
          post.Photo = EntityContext.Photo.First(p => p.Id == photoId);
        }
        catch (InvalidOperationException)
        {
          // This exception is thrown when no data is present
        }
      }

      // Add the new object to the Entity Framework context and persist by calling SaveChanges
      EntityContext.AddToBlogPost(post);
      SaveChanges();

      return post.Id;
    }

    /// <summary>
    /// Returns the top X number of posts in reverse chronological order
    /// </summary>
    /// <param name="number">The number of posts which are to be returned</param>
    /// <remarks>
    /// We are using Linq to Entities to perform the query which we require here, using firstly the
    /// OrderByDescending extension method to sort the posts, and then Take to return X number of
    /// posts from the resulting set
    /// </remarks>
    public List<BlogPost> GetTopXPosts(int number)
    {
      return new List<BlogPost>( EntityContext.BlogPost.OrderByDescending(p => p.PostedOn).Take(number) );
    }

    /// <summary>
    /// Returns a specific post identified by its unique id
    /// </summary>
    /// <param name="id">The unique id of the post to be returned</param>
    public BlogPost GetPost(int id)
    {
      try
      {
        return EntityContext.BlogPost.First(p => p.Id == id);
      }
      catch (InvalidOperationException)
      {
        return null;
      }
    }

    /// <summary>
    /// Returns a collection of posts which are spatially located within the bounds of the circle which is decribed by the
    /// passed latitude, longitude and radius parameters
    /// </summary>
    /// <param name="latitude">The latitude of the center of the circle</param>
    /// <param name="longitude">The longitude of the center of the circle</param>
    /// <param name="radius">The radius of the circle</param>
    /// <remarks>
    /// For this function, we are excuting the BlogPost_GetBySpatialIntersection blog post by calling to it through 
    /// the imported function/method on the Entities context object. The stored procedure takes a geometry data type parameter
    /// which is implicitly converted from a string formatted in the Well Known Text (WKT) format which we construct from the
    /// call to SpatialHelper.GetCircleWKT
    /// </remarks>
    public List<BlogPost> GetByLocation(double latitude, double longitude, double radius)
    {
      return new List<BlogPost>(
        EntityContext.BlogPost_GetBySpatialIntersection(
          SpatialHelper.GetCircleWKT(latitude, longitude, ( radius * Constants.MilesToKilometers ) / Constants.OneDegreeInKilometers , Constants.NumberOfPointsForCircles)
          )
        );
    }
  }
}
