﻿using System;
using System.Linq;
using SummerRoadTrip.Services.Contracts;
using SummerRoadTrip.Model;

namespace SummerRoadTrip.Services
{
  public sealed class MemberService : ServiceBase, IMemberService
  {
    /// <summary>
    /// Returns the member associated with the supplied email address
    /// </summary>
    public Member GetByEmail(string emailAddress)
    {
      try
      {
        return EntityContext.Member.First(m => m.EmailAddress == emailAddress);
      }
      catch (InvalidOperationException)
      {
        // This exception is thrown when no data is present
        return null;
      }
    }

    /// <summary>
    /// Registers a new member with the system
    /// </summary>
    public Member Register(string userName, string emailAddress)
    {
      if (GetByEmail(emailAddress) != null)
      {
        return null;
      }

      Member member = new Member();
      member.Name = userName;
      member.EmailAddress = emailAddress;
      member.CookieKey = null;

      // Add the new object to the Entity Framework context and persist by calling SaveChanges
      EntityContext.AddToMember(member);
      SaveChanges();

      return member;
    }

    /// <summary>
    /// Updates the details for an existing member with a new set of supplied details
    /// </summary>
    public void UpdateDetails(Member member)
    {
      Member originalMember = GetByEmail(member.EmailAddress);

      if (originalMember == null) throw new ArgumentException("Member cannot be null");

      member.CopyTo(originalMember);

      SaveChanges();
    }
  }
}
