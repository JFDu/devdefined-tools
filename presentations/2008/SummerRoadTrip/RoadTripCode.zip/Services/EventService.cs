﻿using System;
using System.Collections.Generic;
using System.Linq;
using SummerRoadTrip.Services.Contracts;
using SummerRoadTrip.Model;

namespace SummerRoadTrip.Services
{
  public sealed class EventService : ServiceBase, IEventService
  {
    /// <summary>
    /// Returns a collection of all Events registered in the system
    /// </summary>
    public List<Event> GetEvents()
    {
      List<Event> events = new List<Event>();

      foreach (Event ev in EntityContext.Event)
      {
        // The location property needs to be handled specially because there is no direct support for handling UDT's
        // in the Entities framework and additionally we are using Well Known Text locally. This helper function 
        // will use an additional call back to SQL Server to select out the location column for this event and return it 
        // as Well Known Text (WKT)
        ev.Location = SpatialHelper.SelectWKTForEntityColumn(typeof(Event), "Location", ev.Id); 

        events.Add(ev);
      }

      return events;
    }

    /// <summary>
    /// Returns a specific Event identified by its unique id
    /// </summary>
    /// <param name="id">The unique id of the event to be returned</param>
    public Event GetEvent(int id)
    {
      try
      {
        Event ev = EntityContext.Event.First(e => e.Id == id);

        // The location property needs to be handled specially -refer to comments in GetEvents method for more detail
        ev.Location = SpatialHelper.SelectWKTForEntityColumn(typeof(Event), "Location", ev.Id);

        return ev;
      }
      catch (InvalidOperationException)
      {
        return null;
      }
    }
  }
}
