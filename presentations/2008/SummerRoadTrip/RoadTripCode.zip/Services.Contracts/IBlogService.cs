﻿using System.Collections.Generic;
using System.ServiceModel;
using SummerRoadTrip.Model;

namespace SummerRoadTrip.Services.Contracts
{
  [ServiceContract]
  public interface IBlogService
  {
    /// <summary>
    /// Adds a new blog post into the system
    /// </summary>
    [OperationContract]
    int Add(string subject, string body, int memberId, int? photoId);

    /// <summary>
    /// Returns a specific post identified by its unique id
    /// </summary>
    /// <param name="id">The unique id of the post to be returned</param>
    [OperationContract]
    BlogPost GetPost(int id);

    /// <summary>
    /// Returns the top X number of posts in reverse chronological order
    /// </summary>
    /// <param name="number">The number of posts which are to be returned</param>
    [OperationContract]
    List<BlogPost> GetTopXPosts(int number);

    /// <summary>
    /// Returns a collection of posts which are spatially located within the bounds of the circle which is decribed by the
    /// passed latitude, longitude and radius parameters
    /// </summary>
    /// <param name="latitude">The latitude of the center of the circle</param>
    /// <param name="longitude">The longitude of the center of the circle</param>
    /// <param name="radius">The radius of the circle</param>
    [OperationContract]
    List<BlogPost> GetByLocation(double latitude, double longitude, double radius);
  }
}
