﻿using System.Collections.Generic;
using SummerRoadTrip.Model;
using System.ServiceModel;
using System.Diagnostics.CodeAnalysis;

namespace SummerRoadTrip.Services.Contracts
{
  [ServiceContract]
  public interface IEventService
  {
    /// <summary>
    /// Returns a collection of all Events registered in the system
    /// </summary>
    [SuppressMessage("Microsoft.Design", "CA1024:UsePropertiesWhereAppropriate"),
     OperationContract]
    List<Event> GetEvents();

    /// <summary>
    /// Returns a specific Event identified by its unique id
    /// </summary>
    /// <param name="id">The unique id of the event to be returned</param>
    [OperationContract]
    Event GetEvent(int id);
  }
}
