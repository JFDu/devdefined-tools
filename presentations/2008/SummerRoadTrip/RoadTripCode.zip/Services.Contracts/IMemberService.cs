﻿using System.ServiceModel;
using SummerRoadTrip.Model;

namespace SummerRoadTrip.Services.Contracts
{
  [ServiceContract]
  public interface IMemberService
  {
    /// <summary>
    /// Returns the member associated with the supplied email address
    /// </summary>
    [OperationContract]
    Member GetByEmail(string emailAddress);

    /// <summary>
    /// Registers a new member with the system
    /// </summary>
    [OperationContract]
    Member Register(string userName, string emailAddress);

    /// <summary>
    /// Updates the details for an existing member with a new set of supplied details
    /// </summary>
    [OperationContract]
    void UpdateDetails(Member member);
  }
}
