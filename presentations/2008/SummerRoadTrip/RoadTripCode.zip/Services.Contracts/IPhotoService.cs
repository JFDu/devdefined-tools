﻿using System.Collections.Generic;
using System.ServiceModel;
using SummerRoadTrip.Model;
using System.Diagnostics.CodeAnalysis;

namespace SummerRoadTrip.Services.Contracts
{
  [ServiceContract]
  public interface IPhotoService
  {
    /// <summary>
    /// Adds a new Photo to the system
    /// </summary>
    [OperationContract]
    int Add(string name, byte[] data, string location);

    /// <summary>
    /// Returns a specific photo identified by its unique id
    /// </summary>
    /// <param name="id">The unique id of the photo to be returned</param>
    [OperationContract]
    Photo GetPhoto(int id);

    /// <summary>
    /// Returns a collection of all Photos registered with the system
    /// </summary>
    [SuppressMessage("Microsoft.Design", "CA1024:UsePropertiesWhereAppropriate"),
     OperationContract]
    List<Photo> GetAllPhotos();

    /// <summary>
    /// Returns a collection of random photos, with the maximum being bounded by the supplied number
    /// </summary>
    /// <param name="number">The maximum number of photos to be returned</param>
    [OperationContract]
    List<Photo> GetRandomPhotos(int number);

    /// <summary>
    /// Returns a collection of photos which are spatially located within the bounds of the circle which is decribed by the
    /// passed latitude, longitude and radius parameters
    /// </summary>
    /// <param name="latitude">The latitude of the center of the circle</param>
    /// <param name="longitude">The longitude of the center of the circle</param>
    /// <param name="radius">The radius of the circle</param>
    [OperationContract]
    List<Photo> GetByLocation(double latitude, double longitude, double radius);
  }
}
