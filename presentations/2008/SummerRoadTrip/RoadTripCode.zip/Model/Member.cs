﻿namespace SummerRoadTrip.Model
{
  /// <remarks>
  /// We are adding some additional behavior into the Member class by using the fact that the Entity Framework generates
  /// partial types. Any code we declare in this partial class will not be overwriten if we regenerate the Entity
  /// definitions
  /// </remarks>
  public partial class Member
  {
    /// <summary>
    /// Copies data from this Member instance into another Member instance which is supplied
    /// </summary>
    public void CopyTo(Member originalMember)
    {
      originalMember.Name = Name;
      originalMember.EmailAddress = EmailAddress;
    }
  }
}
