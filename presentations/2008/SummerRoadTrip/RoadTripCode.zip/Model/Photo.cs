﻿using System;
using System.Globalization;
using System.Runtime.Serialization;

namespace SummerRoadTrip.Model
{
  /// <remarks>
  /// We are adding some additional behavior into the Photo class by using the fact that the Entity Framework generates
  /// partial types. Any code we declare in this partial class will not be overwriten if we regenerate the Entity
  /// definitions
  /// </remarks>
  public partial class Photo
  {
    private double _latitude;
    private double _longitude;
    private byte[] _data;

    /// <summary>
    /// The contents of the photo stores as a byte array
    /// </summary>
    /// <remarks>
    /// We have this property declared here, rather than in the Entity model as we are handling the data property specially to
    /// populate it based on the FILESTREAM based file API's
    /// </remarks>
    [DataMember]
    public byte[] Data
    {
      get { return _data; }
      set { _data = value; }
    }

    /// <summary>
    /// The latitude at which this photo was taken
    /// </summary>
    /// <remarks>
    /// This property is distributed across the wire, and will be used to form an overall location based on the logic in
    /// the Location property below
    /// </remarks>
    [DataMember]
    public double Latitude
    {
      get { return _latitude; }
      set { _latitude = value; }
    }

    /// <summary>
    /// The longitude at which this photo was taken
    /// </summary>
    /// <remarks>
    /// This property is distributed across the wire, and will be used to form an overall location based on the logic in
    /// the Location property below
    /// </remarks>
    [DataMember]
    public double Longitude
    {
      get { return _longitude; }
      set { _longitude = value; }
    }

    /// <summary>
    /// Handles the location of the Event in the Well Known Text (WKT) format
    /// </summary>
    /// <remarks>
    /// Because we wish to deal with our location based data in the Well Known Text format, the Location property
    /// handles moving data in and out of this format using the Latitude and Longitude properties for the underlying
    /// storage
    /// 
    /// Note: This property is NOT distrubuted, but can be rehydrated based on a latitude and longitude
    /// </remarks>
    public string Location
    {
      get
      {
        return String.Format(CultureInfo.CurrentCulture, "POINT ({0} {1})", Latitude, Longitude);
      }

      set
      {
        // Handle null condition with a default positioning at 0,0
        if (String.IsNullOrEmpty(value))
        {
          Latitude = 0;
          Longitude = 0;
          return;
        }

        // Check for invalid WKT
        if (value.IndexOf("(", StringComparison.OrdinalIgnoreCase) < 0 || value.IndexOf(")", StringComparison.OrdinalIgnoreCase) < 0) throw new ArgumentException("Value is not in Well Known Text form");

        string[] coords = value.Substring(value.IndexOf("(", StringComparison.OrdinalIgnoreCase) + 1).Replace(")", String.Empty).Split(' ');

        try
        {
          Latitude = double.Parse(coords[0], CultureInfo.CurrentCulture);
          Longitude = double.Parse(coords[1], CultureInfo.CurrentCulture);
        }
        catch (FormatException)
        {
          Latitude = 0;
          Longitude = 0;
        }
      }
    }
  }
}
