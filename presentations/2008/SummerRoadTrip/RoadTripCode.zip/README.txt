Summer Road Trip 2008 Code Sample
----------------------------------

This is the completed version of the code which was used during the 2008 Summer Road Trip
and is provided "as-is" with no express warranties, guarantees or conditions. You are welcome
to re-use any or all of this code in your solutions as covered by the license found in LICENSE.TXT
in the local directory.

The code has been commented to provide a basic overview and guidance on how the solution
has been put togethor. For more information, please refer to the presentation slides and videos.

To run this sample, you will need the following tools installed:

	- Visual Studio 2008
	- SQL Server 2008 CTP 5 or 6
	- Entity Framework Beta 3
	- Entity Framework Tools for Visual Studio (Beta)
	- Visual Studio Hotfix for connecting to SQL Server 2008 databases

To get started, follow through these steps:

	- Open a command prompt in the Schema folder
	- Run build.cmd <your SQL 2008 instance>
	- The SummerRoadTrip database will now be created and is ready to use
	- Open the code solution in Visual Studio 2008
	- For each .config file throughout the solution, update the connection strings to point to your local database server for each of the connection string instances found


Happy coding!
Jeremy, Chris and Darryl