﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.ServiceModel;
using System.ServiceModel.Activation;
using SummerRoadTrip.Website.Services.Contracts;
using System.Collections.Generic;
using System.ServiceModel.Syndication;
using System.Text;

namespace SummerRoadTrip.Website.Services
{
  [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
  public sealed class Event : IEventService, IDisposable
  {
    private readonly ChannelFactory<SummerRoadTrip.Services.Contracts.IEventService> _factory = new ChannelFactory<SummerRoadTrip.Services.Contracts.IEventService>("EventEndpoint");    
    private readonly SummerRoadTrip.Services.Contracts.IEventService _service;

    public Event()
    {
      _service = _factory.CreateChannel(); 
    }

    /// <summary>
    /// Returns a collection of all Events registered in the system
    /// </summary>
    [SuppressMessage("Microsoft.Design", "CA1002:DoNotExposeGenericLists")]
    public List<Model.Event> GetEvents()
    {
      List<Model.Event> retVal = _service.GetEvents();
      return retVal;
    }

    /// <summary>
    /// Returns all registered Events in the RSS 2.0 format
    /// </summary>
    public Rss20FeedFormatter GetEventsAsRss()
    {
      SyndicationFeed feed = CreateFeed("Summer Road Trip", "Events on the 2008 Summer Road Trip");
      feed.Items = ConvertEventList(_service.GetEvents());
      return feed.GetRss20Formatter(false);
    }

    /// <summary>
    /// Helper method to create a new SyndicationFeed for our Events
    /// </summary>
    private static SyndicationFeed CreateFeed(string title, string description)
    {
      SyndicationFeed feed = new SyndicationFeed();

      feed.Title = new TextSyndicationContent(title);
      feed.Description = new TextSyndicationContent(description);
      feed.Generator = "Event Services";
      feed.Language = "en-nz";
      feed.LastUpdatedTime = DateTime.Now;

      return feed;
    }

    /// <summary>
    /// Helper method to create an enumerable collection of SyndicationItems based on an enumerable collection
    /// of Events and is used for creating a new SyndicationFeed of Events
    /// </summary>
    private static IEnumerable<SyndicationItem> ConvertEventList(IEnumerable<Model.Event> eventList)
    {
      List<SyndicationItem> items = new List<SyndicationItem>();

      foreach (Model.Event ev in eventList)
      {
        SyndicationItem item = new SyndicationItem();

        item.Title = new TextSyndicationContent(ev.Name);
        item.PublishDate = ev.EventTime.Value;
        item.LastUpdatedTime = DateTime.Now;


        item.Id = ev.Id.ToString(CultureInfo.InvariantCulture);

        StringBuilder html = new StringBuilder();
        html.AppendFormat("<p><span>Date: {0}</span><br/><span>Time: {1}</span><br/><span>Venue: {2}</span><br/><span>Speakers: Chris, JB and a membr of the local developer community.</span></p>",
          ev.EventTime.Value.ToString("dd/MM/yyyy", CultureInfo.CurrentCulture),
          ev.EventTime.Value.ToString("hh:mm:ss", CultureInfo.CurrentCulture),
          ev.LocationName
          );

        item.Content = SyndicationContent.CreateHtmlContent(html.ToString());

        items.Add(item);
      }

      return items;
    }

    #region IDisposable Members

    public void Dispose()
    {
      if (_factory != null)
      {
        _factory.Close();
      }

      GC.SuppressFinalize(this);
    }

    #endregion
  }
}
