﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.ServiceModel;
using System.ServiceModel.Activation;
using SummerRoadTrip.Website.Services.Contracts;

namespace SummerRoadTrip.Website.Services
{
  [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
  public sealed class Photo : IPhotoService, IDisposable
  {
    private readonly ChannelFactory<SummerRoadTrip.Services.Contracts.IPhotoService> _factory = new ChannelFactory<SummerRoadTrip.Services.Contracts.IPhotoService>("PhotoEndpoint");
    private readonly SummerRoadTrip.Services.Contracts.IPhotoService _service;

    public Photo()
    {
      _service = _factory.CreateChannel();
    }

    /// <summary>
    /// Returns a specific photo identified by its unique id
    /// </summary>
    /// <param name="id">The unique id of the photo to be returned</param>
    public Model.Photo GetPhoto(string id)
    {
      return _service.GetPhoto(int.Parse(id, CultureInfo.InvariantCulture));
    }

    /// <summary>
    /// Returns a collection of all Photos registered with the system
    /// </summary>
    [SuppressMessage("Microsoft.Design", "CA1002:DoNotExposeGenericLists")]
    public List<Model.Photo> GetAllPhotos()
    {
      return _service.GetAllPhotos();
    }

    /// <summary>
    /// Returns a collection of random photos, with the maximum being bounded by the supplied number
    /// </summary>
    /// <param name="number">The maximum number of photos to be returned</param>
    /// <param name="stripData">Indicates if the data property should be nulled for objects in the return set</param>
    [SuppressMessage("Microsoft.Design", "CA1002:DoNotExposeGenericLists")]
    public List<Model.Photo> GetRandomPhotos(string number, bool stripData)
    {
      List<Model.Photo> photos = _service.GetRandomPhotos(int.Parse(number, CultureInfo.InvariantCulture));

      if (stripData)
      {
        foreach (Model.Photo photo in photos)
        {
          photo.Data = null;
        }
      }

      return photos;
    }

    #region IDisposable Members

    public void Dispose()
    {
      if (_factory != null)
      {
        _factory.Close();
      }

      GC.SuppressFinalize(this);
    }

    #endregion
  }
}
