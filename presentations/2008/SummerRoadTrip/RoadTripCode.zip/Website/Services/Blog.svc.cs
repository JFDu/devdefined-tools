﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.ServiceModel;
using System.ServiceModel.Activation;
using System.ServiceModel.Web;
using SummerRoadTrip.Model;
using SummerRoadTrip.Website.Services.Contracts;

namespace SummerRoadTrip.Website.Services
{
  [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
  public sealed class Blog : IBlogService, IDisposable
  {
    private readonly ChannelFactory<SummerRoadTrip.Services.Contracts.IBlogService> _factory = new ChannelFactory<SummerRoadTrip.Services.Contracts.IBlogService>("BlogEndpoint");
    private readonly SummerRoadTrip.Services.Contracts.IBlogService _service;

    public Blog()
    {
      _service = _factory.CreateChannel();
    }

    /// <summary>
    /// Returns a specific post identified by its unique id
    /// </summary>
    /// <param name="id">The unique id of the post to be returned</param>
    [WebGet(UriTemplate = "blog/{id}", ResponseFormat = WebMessageFormat.Json)]
    public BlogPost GetPost(string id)
    {
      return _service.GetPost(int.Parse(id, CultureInfo.InvariantCulture));
    }

    /// <summary>
    /// Returns the top X number of posts in reverse chronological order
    /// </summary>
    /// <param name="number">The number of posts which are to be returned</param>
    [SuppressMessage("Microsoft.Design", "CA1002:DoNotExposeGenericLists"), WebGet(UriTemplate = "blog/top/{number}", ResponseFormat = WebMessageFormat.Json)]
    public List<BlogPost> GetTopXPosts(string number)
    {
      return _service.GetTopXPosts(int.Parse(number, CultureInfo.InvariantCulture));      
    }

    /// <summary>
    /// Returns a collection of posts which are spatially located within the bounds of the circle which is decribed by the
    /// passed latitude, longitude and radius parameters
    /// </summary>
    /// <param name="latitude">The latitude of the center of the circle</param>
    /// <param name="longitude">The longitude of the center of the circle</param>
    /// <param name="radius">The radius of the circle</param>
    [SuppressMessage("Microsoft.Design", "CA1002:DoNotExposeGenericLists"), WebGet(UriTemplate = "blog/region/{latitude}/{longitude}/{radius}", ResponseFormat = WebMessageFormat.Json)]
    public List<BlogPost> GetByLocation(string latitude, string longitude, string radius)
    {
      return _service.GetByLocation(
        double.Parse(latitude, CultureInfo.InvariantCulture),
        double.Parse(longitude, CultureInfo.InvariantCulture),
        double.Parse(radius, CultureInfo.InvariantCulture));
    }

    #region IDisposable Members

    public void Dispose()
    {
      if (_factory != null)
      {
        _factory.Close();
      }

      GC.SuppressFinalize(this);
    }

    #endregion
  }
}
