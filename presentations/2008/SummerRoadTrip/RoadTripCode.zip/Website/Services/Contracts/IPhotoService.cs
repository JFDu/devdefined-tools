﻿using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.ServiceModel;

namespace SummerRoadTrip.Website.Services.Contracts
{
 [ServiceContract(Name = "PhotoService", Namespace = "SummerRoadTrip.Website.Services.Contracts")]
  public interface IPhotoService
  {
    /// <summary>
    /// Returns a specific photo identified by its unique id
    /// </summary>
    /// <param name="id">The unique id of the photo to be returned</param>
    [OperationContract]
    Model.Photo GetPhoto(string id);

    /// <summary>
    /// Returns a collection of all Photos registered with the system
    /// </summary>
    [SuppressMessage("Microsoft.Design", "CA1002:DoNotExposeGenericLists"), 
      OperationContract]
    List<Model.Photo> GetAllPhotos();

    /// <summary>
    /// Returns a collection of random photos, with the maximum being bounded by the supplied number
    /// </summary>
    /// <param name="number">The maximum number of photos to be returned</param>
    /// <param name="stripData">Indicates if the data property should be nulled for objects in the return set</param>
    [SuppressMessage("Microsoft.Design", "CA1002:DoNotExposeGenericLists"), 
      OperationContract]
    List<Model.Photo> GetRandomPhotos(string number, bool stripData);
  }
}
