﻿using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.ServiceModel;
using SummerRoadTrip.Model;

namespace SummerRoadTrip.Website.Services.Contracts
{
  [ServiceContract(Name = "BlogService", Namespace = "SummerRoadTrip.Website.Services.Contracts")]
  public interface IBlogService
  {
    /// <summary>
    /// Returns a specific post identified by its unique id
    /// </summary>
    /// <param name="id">The unique id of the post to be returned</param>
    [OperationContract]
    BlogPost GetPost(string id);

    /// <summary>
    /// Returns the top X number of posts in reverse chronological order
    /// </summary>
    /// <param name="number">The number of posts which are to be returned</param>
    [SuppressMessage("Microsoft.Design", "CA1002:DoNotExposeGenericLists"), 
      OperationContract]
    List<BlogPost> GetTopXPosts(string number);

    /// <summary>
    /// Returns a collection of posts which are spatially located within the bounds of the circle which is decribed by the
    /// passed latitude, longitude and radius parameters
    /// </summary>
    /// <param name="latitude">The latitude of the center of the circle</param>
    /// <param name="longitude">The longitude of the center of the circle</param>
    /// <param name="radius">The radius of the circle</param>
    [SuppressMessage("Microsoft.Design", "CA1002:DoNotExposeGenericLists"), 
      OperationContract]
    List<BlogPost> GetByLocation(string latitude, string longitude, string radius);
  }
}
