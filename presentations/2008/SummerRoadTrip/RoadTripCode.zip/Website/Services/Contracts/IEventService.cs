﻿using System.Diagnostics.CodeAnalysis;
using System.ServiceModel;
using System.Collections.Generic;
using System.ServiceModel.Syndication;

namespace SummerRoadTrip.Website.Services.Contracts
{
  [ServiceContract(Name="EventService", Namespace="SummerRoadTrip.Website.Services.Contracts")]
  public interface IEventService
  {
    /// <summary>
    /// Returns a collection of all Events registered in the system
    /// </summary>
    [SuppressMessage("Microsoft.Design", "CA1002:DoNotExposeGenericLists"), 
      OperationContract]
    List<Model.Event> GetEvents();

    /// <summary>
    /// Returns all registered Events in the RSS 2.0 format
    /// </summary>
    [OperationContract]
    Rss20FeedFormatter GetEventsAsRss();
  }
}
