﻿using System;
using System.Web.UI;

namespace SummerRoadTrip.Website
{
  public partial class Login : Page
  {
    /// <summary>
    /// Sets the initial state for the page and triggers any default bindings
    /// </summary>
    protected void Page_Load(object sender, EventArgs e)
    {
    }
  }
}
