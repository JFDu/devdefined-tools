﻿using System;
using System.Globalization;
using System.Web.UI;
using System.Web.UI.WebControls;
using SummerRoadTrip.Model;
using SummerRoadTrip.Website.Services;

namespace SummerRoadTrip.Website
{
  public partial class Index : Page
  {
    /// <summary>
    /// Sets the initial state for the page and triggers any default bindings
    /// </summary>
    protected void Page_Load(object sender, EventArgs e)
    {
      blogPopup.Style["visibility"] = "hidden";

      if (!IsPostBack)
      {
        ShowLatestBlogPosts();
      }
    }

    /// <summary>
    /// Populates the Blog Post repeater with the latest blog posts in the system
    /// </summary>
    /// <remarks>
    /// This call uses an ObjectDataSource and binds it to a server side method which returns BlogPost objects
    /// The SelectMethod defines the Method and Parameters which are passed to the call
    /// </remarks>
    private void ShowLatestBlogPosts()
    {
      blogDataSource.TypeName = "SummerRoadTrip.Website.Services.Blog";
      blogDataSource.SelectMethod = "GetTopXPosts";
      blogDataSource.SelectParameters.Clear();
      blogDataSource.SelectParameters.Add("number", TypeCode.String, "4");
      blogRepeater.DataBind();
    }

    /// <summary>
    /// Performs a spatial search and populates the Blog Post repeater with the results
    /// </summary>
    /// <remarks>
    /// This call uses an ObjectDataSource and binds it to a server side method which will perform the spatial
    /// query and then return a set of BlogPost objects
    /// </remarks>
    protected void RefreshButton_Click(object sender, EventArgs e)
    {
      blogDataSource.TypeName = "SummerRoadTrip.Website.Services.Blog";
      blogDataSource.SelectMethod = "GetByLocation";
      blogDataSource.SelectParameters.Clear();
      blogDataSource.SelectParameters.Add("latitude", TypeCode.String, blogLatitude.Value);
      blogDataSource.SelectParameters.Add("longitude", TypeCode.String, blogLongitude.Value);
      blogDataSource.SelectParameters.Add("radius", TypeCode.String, blogRadius.Value);
      blogRepeater.DataBind();

      titleLatest.Src = "images/titleSearchResults.png";
    }

    /// <summary>
    /// Handles the AJAX call to respond to an event on the page
    /// </summary>
    /// <remarks>
    /// This handler will be called via client side script and will trigger some server side processing and rendering changes
    /// that will be handled by ASP.NET AJAX and the UpdatePanel on the page
    /// 
    /// Currently the only command we are processing will show additional details for a blog post on clicking the "More.." link
    /// </remarks>
    protected void blogRepeater_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
      if (e.CommandName.ToUpperInvariant().Equals("SHOWMORE"))
      {
        BlogPost post = new Blog().GetPost(((LinkButton)e.CommandSource).CommandArgument);

        if ( post == null ) return;

        blogTitle.Text = post.Subject;
        blogContent.InnerHtml = post.Body;

        // Validate that the post has an associated photo
        if (post.PhotoReference.EntityKey != null)
        {
          string photoId = post.PhotoReference.EntityKey.EntityKeyValues[0].Value.ToString();
          blogImage.ImageUrl = "Photo.axd?id=" + photoId + "&isthumbnail=0";
          blogImageLink.NavigateUrl = "Photo.axd?id=" + photoId + "&isthumbnail=0";
          blogImageLink.Visible = true;
        }
        else
        {
          blogImageLink.Visible = false;
        }

        blogPopup.Style["visibility"] = "visible";
      }
    }
  }
}
