﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.ServiceModel;
using System.Web.UI;
using SummerRoadTrip.Model;
using SummerRoadTrip.Services.Contracts;

namespace SummerRoadTrip.Website
{
  public partial class AddBlog : Page
  {
    private readonly ChannelFactory<IBlogService> _blogFactory = new ChannelFactory<IBlogService>("BlogEndpoint");
    private readonly ChannelFactory<IPhotoService> _photoFactory = new ChannelFactory<IPhotoService>("PhotoEndpoint");
    private IBlogService _blogService;
    private IPhotoService _photoService;

    /// <summary>
    /// Sets the initial state for the page and triggers any default bindings
    /// </summary>
    protected void Page_Load(object sender, EventArgs e)
    {
      if (Request["lat"] != null && Request["long"] != null)
      {
        latitudeTextBox.Text = Request["lat"];
        longitudeTextBox.Text = Request["long"];
      }
    }

    /// <summary>
    /// Handles the creation of a new blog post optionally with an associated photo
    /// </summary>
    [SuppressMessage("Microsoft.Naming", "CA1709:IdentifiersShouldBeCasedCorrectly", MessageId = "upload")]
    protected void uploadButton_Click(object sender, EventArgs e)
    {
      double latitude = double.Parse(latitudeTextBox.Text, CultureInfo.InvariantCulture);
      double longitude = double.Parse(longitudeTextBox.Text, CultureInfo.InvariantCulture);
      int? photoId = null;

      // If we have a photo, then we need to provision it into the system and then use the newly created
      // identifier in the creation of the blog post
      if (photoFileUpload != null && photoFileUpload.HasFile)
      {
        Photo photo = new Photo();

        photo.Latitude = latitude;
        photo.Longitude = longitude;
        photo.Name = subjectTextBox.Text;
        photo.Data = photoFileUpload.FileBytes;

        _photoService = _photoFactory.CreateChannel();
        photoId = _photoService.Add(photo.Name, photo.Data, photo.Location);
      }

      _blogService = _blogFactory.CreateChannel();
      _blogService.Add(subjectTextBox.Text, bodyTextBox.Text, 1, photoId);
    }
  }
}
