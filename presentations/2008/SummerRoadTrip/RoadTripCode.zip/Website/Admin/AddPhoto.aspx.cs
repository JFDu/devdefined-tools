﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.ServiceModel;
using System.Web.UI;
using SummerRoadTrip.Model;
using SummerRoadTrip.Services.Contracts;

namespace SummerRoadTrip.Website
{
  public partial class AddPhoto : Page
  {
    private readonly ChannelFactory<IPhotoService> _factory = new ChannelFactory<IPhotoService>("PhotoEndpoint");
    private IPhotoService _service;

    /// <summary>
    /// Sets the initial state for the page and triggers any default bindings
    /// </summary>
    protected void Page_Load(object sender, EventArgs e)
    {
      if (Request["lat"] != null && Request["long"] != null)
      {
        latitudeTextBox.Text = Request["lat"];
        longitudeTextBox.Text = Request["long"];
      }
    }

    /// <summary>
    /// Handles the upload of a new photo and provisions it into the system
    /// </summary>
    [SuppressMessage("Microsoft.Naming", "CA1709:IdentifiersShouldBeCasedCorrectly", MessageId = "upload")]
    protected void uploadButton_Click(object sender, EventArgs e)
    {
      double latitude = double.Parse(latitudeTextBox.Text, CultureInfo.InvariantCulture);
      double longitude = double.Parse(longitudeTextBox.Text, CultureInfo.InvariantCulture);

      Photo photo = new Photo();
      photo.Latitude = latitude;
      photo.Longitude = longitude;
      photo.Name = nameTextBox.Text;

      if (photoFileUpload != null && photoFileUpload.HasFile)
      {
        photo.Data = photoFileUpload.FileBytes;
      }

      _service = _factory.CreateChannel();
      _service.Add(photo.Name, photo.Data, photo.Location);
    }
  }
}
