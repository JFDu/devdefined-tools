﻿var map = null;
var slDrawing = new VEShapeLayer();
var slEvents = new VEShapeLayer();
var slPhotos = new VEShapeLayer();

function GetMap()
{
   map = new VEMap('mapControl');
   map.SetDashboardSize(VEDashboardSize.Tiny);
   map.LoadMap(new VELatLong(-41.2667, 173.2931), 6 ,'r' ,false);
   map.ClearInfoBoxStyles();
   
   DefineCustomIcons();
   
   map.AddShapeLayer(slEvents);
   map.AddShapeLayer(slPhotos);
   map.AddShapeLayer(slDrawing);
   
   AddEventPushPins();
   
   GetRandomPhotos();
   
}

var iconIcecream;
var iconIcecreamMelted;
var iconPhoto;
var iconRSSFeed;
var iconKowhai;
var iconRata;
var iconFrangipani;

function DefineCustomIcons()
{
    //Icecream
    iconIcecream = "<span style='position:relative;left:-"+15+"px;top:-"+54+"px;'><img src='"+'images/iceCreamPointer.png'+"' /></span>";
     
    //Icecream Melted
    iconIcecreamMelted = "<span style='position:relative;left:-"+15+"px;top:-"+54+"px;'><img src='"+'images/iceCreamMeltedPointer.png'+"' /></span>";
    
    //Upload photo
    iconPhoto = new VECustomIconSpecification();
    iconPhoto.Image = 'images/cameraIcon.png';
    iconPhoto.TextContent=" ";
    
    //Icecream Melted
    iconRSSFeed = new VECustomIconSpecification();
    iconRSSFeed.Image = 'images/feed.png';
    
    //Kowhai
    iconKowhai = new VECustomIconSpecification();
    iconKowhai.Image = 'images/iconKowhai.png';
    
    //Rata
    iconRata = new VECustomIconSpecification();
    iconRata.Image = 'images/iconRata.png';
    
    //Frangipani
    iconFrangipani = new VECustomIconSpecification();
    iconFrangipani.Image = 'images/iconFragipani.png';
    
}

function UpdateFeedArea(feedUrl)
{
    //alert(feedUrl);
}


function AddEventPushPins()
{
    SummerRoadTrip.Website.Services.Contracts.EventService.GetEvents(AddEventPushPinsCallback);
}

function AddEventPushPinsCallback(sender,e)
{
    
    if(sender == null || sender == undefined)
        return;

    var numberOfEvents = sender.length;
    for(var i = 0; i < numberOfEvents; i++)
    {
        var currentEvent = sender[i];

        var icon = new VEShape(VEShapeType.Pushpin, new VELatLong(currentEvent.Latitude, currentEvent.Longitude));

        if(currentEvent.EventTime > new Date())
            icon.SetCustomIcon(iconIcecream); 
        else
            icon.SetCustomIcon(iconIcecreamMelted)
        
        icon.SetDescription(GetEventInfoBox(currentEvent));

        slEvents.AddShape(icon);
    }
}



function GetFeed()
{
    actionTaken='GetFeed';
    alert("To search. Left click on map to set center of search radius. Move mouse to set radius. Right click to confirm radius and perform search.");
    Draw('circle');
    document.getElementById("contentMap").focus();
}

function Upload()
{
    actionTaken='Upload';
    Draw('point');
}

function Blog()
{
    actionTaken='Blog';
    Draw('point');
}