﻿
var myGeomType = null;
var myCurrentShape = null;
var myPoints = new Array();
var myDistance = 0;
var tempShape = null;
var tempPoints = null;
var tempDistance = 0;
var myCirclePoints = null;
var tempCircle = null;
var i = 1;
var actionTaken = "";


function Draw(geomType)
{
    myGeomType = geomType;
    map.AttachEvent("onclick", DrawPolyMouseClick);
    map.AttachEvent("onmousemove", MouseMove);
    document.getElementById("mapControl").style.cursor='crosshair';
}

function MouseMove(e)
{
    var x = e.mapX;
    var y = e.mapY;
    pixel = new VEPixel(x, y);
    var LL = map.PixelToLatLong(pixel);
}

function DrawPolyMouseClick(e)
{
    var x = e.mapX;
    var y = e.mapY;
    pixel = new VEPixel(x, y);
    var LL = map.PixelToLatLong(pixel);

    if (myPoints.length == 0 && myGeomType != "point") 
    {
        map.DetachEvent("onmousemove", MouseMove);
        map.AttachEvent("onmousemove", DrawPolyMouseMove);
    }
    
    if (myGeomType == "circle" && myPoints.length == 2)
    {
        myPoints[1] = LL;
        myDistance = tempDistance;
    }
    else
    {
        myPoints.push(LL);
        myDistance = myDistance + tempDistance;
    }
    
    if (e.rightMouseButton)
    {
        try
        {
            map.DetachEvent("onmousemove", DrawPolyMouseMove);
            map.DetachEvent("onclick", DrawPolyMouseClick);
            slDrawing.DeleteShape(tempShape);
            slDrawing.DeleteShape(tempCircle);
        }
        catch (err)
        {
        }
        
        myCurrentShape = "shape" + i;
        myDistance = Math.round(myDistance * 1000) / 1000;
        switch (myGeomType) 
        {
            case "circle":
                myCurrentShape = new VEShape(VEShapeType.Polygon, myCirclePoints);
                myCurrentShape.SetCustomIcon(iconRSSFeed);        
                        
                var feedUrl = "http://site/rss/area/circle/" + LL.Latitude + "/" + LL.Longitude + "/" + myDistance;
                document.getElementById("blogLatitude").value = LL.Latitude;
                document.getElementById("blogLongitude").value = LL.Longitude;
                document.getElementById("blogRadius").value = myDistance;
                document.getElementById("rssHref").href = feedUrl;
                document.getElementById("titleLatest").src = "images/titleSearchResults.png";
                document.getElementById("blogRefreshButton").click();
                
                                
                myCurrentShape.SetLineColor(new VEColor(120,120,120,.25));
                myCurrentShape.SetLineWidth(1);
                myCurrentShape.SetFillColor(new VEColor(120,0,0,.15));
                slDrawing.AddShape(myCurrentShape);
                UpdateFeedArea(feedUrl);
                break;
            case "point":
                myCurrentShape = new VEShape(VEShapeType.Pushpin, LL);
                myCurrentShape.SetCustomIcon(iconPhoto);
                slDrawing.AddShape(myCurrentShape);
                if(actionTaken = 'Blog')
                {
                    window.open('admin/addblog.aspx?lat=' + LL.Latitude + '&long=' + LL.Longitude,'mywindow','width=400,height=200,toolbar=yes, location=yes,directories=yes,status=yes,menubar=yes,scrollbars=yes,copyhistory=yes, resizable=yes');                
                }
                else
                {
                    window.open('admin/addphoto.aspx?lat=' + LL.Latitude + '&long=' + LL.Longitude,'mywindow','width=400,height=200,toolbar=yes, location=yes,directories=yes,status=yes,menubar=yes,scrollbars=yes,copyhistory=yes, resizable=yes');                
                }
                break;
        }
        
        document.getElementById("mapControl").style.cursor = 'http://maps.live.com/cursors/grab.cur';
    }
    else
    {
        document.getElementById("mapControl").style.cursor='crosshair';
    }
}

function DrawPolyMouseMove(e)
{
    var x = e.mapX;
    var y = e.mapY;
    pixel = new VEPixel(x, y);
    var LL = map.PixelToLatLong(pixel);
    
    tempPoints = myPoints.slice(0, myPoints.length);
    
    if (myGeomType == "circle" && tempPoints.length == 2)
    {
        tempPoints[1] = LL;
        tempDistance = getDistance(tempPoints[0], LL);
    }
    else
    {
        tempPoints.push(LL);
        tempDistance = getDistance(tempPoints[myPoints.length-1], LL);
    }

    var dummy = document.getElementById("divDistance");
    dummy.style.left = e.clientX + "px";
    dummy.style.top = e.clientY + "px";
    dummy.innerHTML = Math.round((myDistance + tempDistance) * 1000) / 1000;

    try
    {
        slDrawing.DeleteShape(tempShape);
        slDrawing.DeleteShape(tempCircle);
    }
    catch (err)
    {
    }
    
    if (tempPoints.length == 2)
    {
        tempShape = new VEShape(VEShapeType.Polyline, tempPoints);
        tempShape.HideIcon();
        slDrawing.AddShape(tempShape);
        if (myGeomType == "circle")
        {
            GetCircle();
            tempCircle = new VEShape(VEShapeType.Polygon, myCirclePoints);
            tempCircle.HideIcon();
            slDrawing.AddShape(tempCircle);
        }
    }
    
}

//calculate distance
function getDistance(p1, p2) 
{
    p1Lat = latLonToRadians(p1.Latitude);
	p1Lon = latLonToRadians(p1.Longitude);
	
	p2Lat = latLonToRadians(p2.Latitude);
	p2Lon = latLonToRadians(p2.Longitude);	
	
	var R = 6371; // earth's mean radius in km
	var dLat  = p2Lat - p1Lat;
	var dLong = p2Lon - p1Lon;
	var a = Math.sin(dLat/2) * Math.sin(dLat/2) + Math.cos(p1Lat) * Math.cos(p2Lat) * Math.sin(dLong/2) * Math.sin(dLong/2);
	var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
	var disKm = R * c;
	//var disMiles = disKm * 0.6214;	
	return (disKm);
}

//convert lat/long in degrees to radians
function latLonToRadians(point) 
{
	return point * Math.PI / 180;	
}

//Draw Circle
function GetCircle()
{
    var R = 6371; // earth's mean radius in km
    var lat = (myPoints[0].Latitude * Math.PI) / 180; //rad
    var lon = (myPoints[0].Longitude * Math.PI) / 180; //rad
    var d = parseFloat(tempDistance) / R;  // d = angular distance covered on earth's surface
    myCirclePoints = new Array();
    for (x = 0; x <= 360; x++) 
    { 
        var p2 = new VELatLong(0,0)            
        brng = x * Math.PI / 180; //rad
        p2.Latitude = Math.asin(Math.sin(lat)*Math.cos(d) + Math.cos(lat)*Math.sin(d)*Math.cos(brng));
        p2.Longitude = ((lon + Math.atan2(Math.sin(brng)*Math.sin(d)*Math.cos(lat), Math.cos(d)-Math.sin(lat)*Math.sin(p2.Latitude))) * 180) / Math.PI;
        p2.Latitude = (p2.Latitude * 180) / Math.PI;
        myCirclePoints.push(p2);
    }
    return myCirclePoints;
}

function SetInfo()
{
    myCurrentShape.SetTitle(document.getElementById("txtShapeTitle").value);
    myCurrentShape.SetDescription(document.getElementById("txtShapeDetails").value + "<br><a href='javascript:Delete(\"" + myCurrentShape.GetID() + "\")'>Delete</a>");

    myPoints = new Array();
    tempPoints = null;
    myDistance = 0;
    tempDistance = 0;
    
    var dummy = document.getElementById("divShapeInfo").style.visibility = "hidden";
    document.getElementById("txtShapeTitle").value = "";
    document.getElementById("txtShapeDetails").value = "";
}

function Delete(shape)
{
    var delShape = slDrawing.GetShapeByID(shape);
    slDrawing.DeleteShape(delShape);
    
}