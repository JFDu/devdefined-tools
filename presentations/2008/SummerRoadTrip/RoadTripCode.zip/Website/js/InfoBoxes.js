﻿
function GetEventInfoBox(event)
{
    var mapPopup = '<div class="eventPopup">' +
			    '<h4>' + event.Name + '</h4>' +	
					'<p>' +
						'<span class="eventDate">Date: ' + event.EventTime.formatDate("F dS") + '</span><br />' +
						'<span class="time">Time: ' + event.EventTime.formatDate("h:i A") + '</span><br />' +
						'<span class="venue">Venue: ' + event.LocationName + '</span><br />' +
						'<span class="speakers">Speakers: Chris, JB and a membr of the local developer community.</span><br />' +
					'</p>'+
				'</div>';
	return mapPopup;
}