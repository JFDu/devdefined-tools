﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Drawing;
using System.Drawing.Imaging;
using System.Globalization;
using System.IO;
using System.ServiceModel;
using System.Web;
using SummerRoadTrip.Model;
using SummerRoadTrip.Services.Contracts;

namespace SummerRoadTrip.Website
{
  public sealed class PhotoHandler : IHttpHandler, IDisposable
  {
    private readonly ChannelFactory<IPhotoService> _factory;
    private readonly IPhotoService _service;

    public PhotoHandler()
    {
      _factory = new ChannelFactory<IPhotoService>("PhotoEndpoint");
      _service = _factory.CreateChannel();
    }

    /// <summary>
    /// The handler is always reusable
    /// </summary>
    public bool IsReusable
    {
      get { return true; }
    }

    /// <summary>
    /// Processes inbound requests and writes the resulting response to the response stream
    /// </summary>
    [SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes")]
    public void ProcessRequest(HttpContext context)
    {
      try
      {
        int id = 0;
        int isThumbnail = 0;

        #region Parse query string parameters
        try
        {
          id = int.Parse(context.Request.QueryString["id"], CultureInfo.InvariantCulture);
        }
        catch ( FormatException )
        {          
        }

        try
        {
          isThumbnail = int.Parse(context.Request.QueryString["isThumbnail"], CultureInfo.InvariantCulture);
        }
        catch ( FormatException )
        {
        }
        #endregion

        // Fetch the photo data from our services tier
        Photo photo = _service.GetPhoto(id);

        if (photo == null) return;

        // Attach a copyright to the image
        Bitmap originalImage = new Bitmap(new MemoryStream(photo.Data));
        Bitmap alteredImage;

        AttachCopyright(originalImage);

        // Check if we need to produce a thumbnail of the original image
        if (isThumbnail > 0)
        {
          alteredImage = new Bitmap(originalImage.GetThumbnailImage(85, 57, null, IntPtr.Zero));
        }
        else
        {
          alteredImage = originalImage;
        }

        // Write the newly created photo out to the response stream
        context.Response.ContentType = "image/jpeg";
        alteredImage.Save(context.Response.OutputStream, ImageFormat.Jpeg);
        alteredImage.Dispose();
      }
      catch (Exception ex)
      {
        // DEBUG: This is purely for debugging any issues in the handler and would normally be replaced
        // by exception management code
        context.Response.Write(ex.ToString());
      }
    }

    /// <summary>
    /// Helper function to attach the copyright text to an image
    /// </summary>
    private static void AttachCopyright(Bitmap originalImage)
    {
      Graphics graphics = Graphics.FromImage(originalImage);
      Font font = new Font("Verdana", 14, GraphicsUnit.Pixel);

      graphics.DrawString("(c) 2008 SummerRoadTrip", font, new SolidBrush(Color.White), 5, originalImage.Height - font.Height - 5);

      font.Dispose();
      graphics.Dispose();
    }

    public void Dispose()
    {
      if (_factory != null)
      {
        _factory.Close();
      }

      GC.SuppressFinalize(this);
    }
  }
}
