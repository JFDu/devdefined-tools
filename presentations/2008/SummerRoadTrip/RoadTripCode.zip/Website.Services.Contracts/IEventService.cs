﻿using System.ServiceModel;
using System.Collections.Generic;
using System.ServiceModel.Syndication;

namespace SummerRoadTrip.Website.Services.Contracts
{
  [ServiceContract(Name="EventService", Namespace="SummerRoadTrip.Website.Services.Contracts")]
  public interface IEventService
  {
    [OperationContract]
    List<SummerRoadTrip.Model.Event> GetEvents();

    [OperationContract]
    bool RegisterForEvent(int id, string emailAddress);

    [OperationContract]
    Rss20FeedFormatter GetEventsAsRss();
  }
}
