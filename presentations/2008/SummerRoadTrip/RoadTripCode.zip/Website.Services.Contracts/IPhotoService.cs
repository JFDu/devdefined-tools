﻿using System.Collections.Generic;
using System.ServiceModel;

namespace SummerRoadTrip.Website.Services.Contracts
{
 [ServiceContract(Name = "PhotoService", Namespace = "SummerRoadTrip.Website.Services.Contracts")]
  public interface IPhotoService
  {
    [OperationContract]
    SummerRoadTrip.Model.Photo GetPhoto(string id);

    [OperationContract]
    List<SummerRoadTrip.Model.Photo> GetAllPhotos();

    [OperationContract]
    List<SummerRoadTrip.Model.Photo> GetRandomPhotos(string number, bool stripData);
  }
}
