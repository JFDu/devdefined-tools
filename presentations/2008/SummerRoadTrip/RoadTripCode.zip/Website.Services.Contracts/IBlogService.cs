﻿using System.Collections.Generic;
using System.ServiceModel;
using SummerRoadTrip.Model;

namespace SummerRoadTrip.Website.Services.Contracts
{
    [ServiceContract(Name = "BlogService", Namespace = "SummerRoadTrip.Website.Services.Contracts")]
  public interface IBlogService
  {
    [OperationContract]
    BlogPost GetPost(string id);

    [OperationContract]
    List<BlogPost> GetTopXPosts(string number);

    [OperationContract]
    List<BlogPost> GetByLocation(string latitude, string longitude, string radius);
  }
}
