﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Transactions;
using SummerRoadTrip.Model;
using System.Configuration;

namespace SummerRoadTrip.UnitTests
{
  [TestClass]
  public class TestFixture
  {
    private TestContext _instance;
    private TransactionScope _scope;
    protected Entities _context = new Entities(ConfigurationManager.ConnectionStrings["Entities"].ConnectionString);

    public TestContext TestContext
    {
      get
      {
        return _instance;
      }
      set
      {
        _instance = value;
      }
    }

     [TestInitialize]
     public void TestInitialize() 
     { 
       _scope = new TransactionScope();
     }
    
     [TestCleanup]
     public void MyTestCleanup() 
     {
       _scope.Dispose();
     }
  }
}
