﻿using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SummerRoadTrip.Model;

namespace SummerRoadTrip.UnitTests.Model
{
  public class EventTests : TestFixture
  {
    [TestMethod]
    public void FindOne()
    {
      Event ev = _context.Event.First(e => e.Id == 1);

      Assert.IsNotNull(ev);
    }

    [TestMethod]
    public void FindAll()
    {
      Assert.IsNotNull(_context.Event);
      Assert.AreEqual(11, _context.Event.Count());
    }

    [TestMethod]
    public void Location()
    {
      Event ev = new Event();

      ev.Latitude = 12;
      ev.Longitude = 34;

      Assert.AreEqual("POINT (12 34)", ev.Location);

      ev.Location = "POINT (56 78)";

      Assert.AreEqual(56, ev.Latitude);
      Assert.AreEqual(78, ev.Longitude);
    }
  }
}
