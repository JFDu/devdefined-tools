﻿using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SummerRoadTrip.Model;

namespace SummerRoadTrip.UnitTests.Model
{
  public class PhotoTests : TestFixture
  {
    [TestMethod]
    public void FindOne()
    {
      Photo photo = _context.Photo.First(p => p.Id == 1);

      Assert.IsNotNull(photo);
    }

    [TestMethod]
    public void FindAll()
    {
      Assert.IsNotNull(_context.Photo);
      Assert.AreEqual(5, _context.Photo.Count());
    }

    [TestMethod]
    public void Location()
    {
      Photo photo = new Photo();

      photo.Latitude = 12;
      photo.Longitude = 34;

      Assert.AreEqual("POINT (12 34)", photo.Location);

      photo.Location = "POINT (56 78)";

      Assert.AreEqual(56, photo.Latitude);
      Assert.AreEqual(78, photo.Longitude);
    }
  }
}
