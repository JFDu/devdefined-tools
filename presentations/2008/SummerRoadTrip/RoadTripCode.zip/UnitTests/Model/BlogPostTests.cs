﻿using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SummerRoadTrip.Model;

namespace SummerRoadTrip.UnitTests.Model
{
  public class BlogPostTests : TestFixture
  {
    [TestMethod]
    public void FindOne()
    {
      BlogPost post = _context.BlogPost.First(p => p.Id == 1);

      Assert.IsNotNull(post);
    }

    [TestMethod]
    public void FindAll()
    {
      Assert.IsNotNull(_context.BlogPost);
      Assert.AreEqual(5, _context.BlogPost.Count());
    }

    [TestMethod]
    public void HasComments()
    {
      BlogPost post = _context.BlogPost.Include("BlogComment").First(p => p.Id == 1);

      Assert.IsNotNull(post.BlogComment);
      Assert.AreEqual(1, post.BlogComment.Count);
    }
  }
}
