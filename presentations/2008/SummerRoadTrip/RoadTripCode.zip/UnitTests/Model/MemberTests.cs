﻿using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SummerRoadTrip.Model;

namespace SummerRoadTrip.UnitTests.Model
{
  public class MemberTests : TestFixture
  {
    [TestMethod]
    public void FindOne()
    {
      Member member = _context.Member.First(m => m.Id == 1);

      Assert.IsNotNull(member);
    }

    [TestMethod]
    public void FindAll()
    {
      Assert.IsNotNull(_context.Member);
      Assert.AreEqual(2, _context.Member.Count());
    }

    [TestMethod]
    public void CopyTo()
    {
      Member m1 = _context.Member.First(m => m.Id == 1);
      Member m2 = new Member();

      m1.CopyTo(m2);

      Assert.AreEqual(m1.Name, m2.Name);
      Assert.AreEqual(m1.EmailAddress, m2.EmailAddress);
    }
  }
}
