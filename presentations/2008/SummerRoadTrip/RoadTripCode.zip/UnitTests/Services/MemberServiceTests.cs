﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using SummerRoadTrip.Services.Contracts;
using SummerRoadTrip.Services;
using SummerRoadTrip.Model;

namespace SummerRoadTrip.UnitTests.Services
{
  public class MemberServiceTests : TestFixture
  {
    [TestMethod]
    public void Register()
    {
      IMemberService service = new MemberService();

      Member newMember = service.Register("Darryl Burling", "darryl.burling@microsoft.com");

      Assert.IsNotNull(newMember);
      Assert.AreEqual(newMember.Name, "Darryl Burling");
      Assert.AreEqual(newMember.EmailAddress, "darryl.burling@microsoft.com");

      newMember = service.GetByEmail("darryl.burling@microsoft.com");
      Assert.IsNotNull(newMember);
    }

    [TestMethod]
    public void CannotRegisterExistingEmailAddress()
    {
      IMemberService service = new MemberService();

      Member newMember = service.Register( "Jeremy Boyd", "jeremy@mindscape.co.nz" );

      Assert.IsNull(newMember);
    }

    [TestMethod]
    public void GetByEmail()
    {
      IMemberService service = new MemberService();

      Member member = service.GetByEmail("jeremy@mindscape.co.nz");

      Assert.IsNotNull(member);

      member = service.GetByEmail("foo@bar.com");

      Assert.IsNull(member);
    }

    [TestMethod]
    public void UpdateDetails()
    {
      IMemberService service = new MemberService();

      Member member = service.GetByEmail("jeremy@mindscape.co.nz");
      member.Name = "JB";

      service.UpdateDetails(member);

      member = service.GetByEmail("jeremy@mindscape.co.nz");

      Assert.AreEqual("JB", member.Name);
    }
  }
}
