﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SummerRoadTrip.Services;

namespace SummerRoadTrip.UnitTests.Services
{
	public class SpatialHelperTests : TestFixture
	{
    [TestMethod]
    public void GenerateCircleWKT()
    {
      Assert.AreEqual("POLYGON ((50 60, 60 50, 50 40, 40 50, 50 60))", SpatialHelper.GetCircleWKT(50, 50, 10, 4));

      Assert.AreEqual("POLYGON ((50 60, 55.8779 58.0902, 59.5106 53.0902, 59.5106 46.9098, 55.8779 41.9098, 50 40, 44.1221 41.9098, 40.4894 46.9098, 40.4894 53.0902, 44.1221 58.0902, 50 60))", SpatialHelper.GetCircleWKT(50, 50, 10, 10));

      Assert.AreEqual("POLYGON ((50 60, 53.0902 59.5106, 55.8779 58.0902, 58.0902 55.8779, 59.5106 53.0902, 60 50, 59.5106 46.9098, 58.0902 44.1221, 55.8779 41.9098, 53.0902 40.4894, 50 40, 46.9098 40.4894, 44.1221 41.9098, 41.9098 44.1221, 40.4894 46.9098, 40 50, 40.4894 53.0902, 41.9098 55.8779, 44.1221 58.0902, 46.9098 59.5106, 50 60))", SpatialHelper.GetCircleWKT(50, 50, 10, 20));
    }

    [TestMethod]
    public void GetOriginFromCircleWKT()
    {
      double[] origin = SpatialHelper.GetOriginFromCircleWKT("POLYGON ((50 60, 60 50, 50 40, 40 50, 50 60))", 10);

      Assert.AreEqual(2, origin.Length);
      Assert.AreEqual(50, origin[0]);
      Assert.AreEqual(50, origin[1]);

      origin = SpatialHelper.GetOriginFromCircleWKT(SpatialHelper.GetCircleWKT(35, 45, 10, 4), 10);

      Assert.AreEqual(2, origin.Length);
      Assert.AreEqual(35, origin[0]);
      Assert.AreEqual(45, origin[1]);
    }

    [TestMethod]
    [ExpectedException(typeof(ArgumentException))]
    public void GetOriginFromCircleWKTHandlesNullWKT()
    {
      SpatialHelper.GetOriginFromCircleWKT(null, 10);
    }

    [TestMethod]
    [ExpectedException(typeof(ArgumentException))]
    public void GetOriginFromCircleWKTHandlesEmptyWKT()
    {
      SpatialHelper.GetOriginFromCircleWKT(String.Empty, 10);
    }

    [TestMethod]
    [ExpectedException(typeof(ArgumentException))]
    public void GetOriginFromCircleWKTHandlesInvalidWKT()
    {
      SpatialHelper.GetOriginFromCircleWKT("foo", 10);
    }
	}
}
