﻿using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SummerRoadTrip.Model;
using SummerRoadTrip.Services;
using SummerRoadTrip.Services.Contracts;

namespace SummerRoadTrip.UnitTests.Services
{
  public class BlogServiceTests : TestFixture
  {
    [TestMethod]
    public void CanAdd()
    {
      IBlogService service = new BlogService();

      int existingCount = service.GetTopXPosts(99).Count;

      service.Add("Foo", "Bar", 1, null);

      Assert.AreEqual(existingCount + 1, service.GetTopXPosts(99).Count);
    }

    [TestMethod]
    public void GetPost()
    {
      IBlogService service = new BlogService();
      BlogPost post = service.GetPost(1);

      Assert.IsNotNull(post);
      Assert.AreEqual("Welcome to the Summer Road Trip", post.Subject);

      Assert.IsNull(service.GetPost(0));
    }

    [TestMethod]
    public void GetTopXPosts()
    {
      IBlogService service = new BlogService();
      List<BlogPost> posts = service.GetTopXPosts(99);

      Assert.AreEqual(5, posts.Count);

      posts = service.GetTopXPosts(0);

      Assert.AreEqual(0, posts.Count);
    }

    [TestMethod, Ignore]
    public void GetByLocation()
    {
      IBlogService service = new BlogService();
      List<BlogPost> posts = service.GetByLocation(-36, 174, 1);

      Assert.AreEqual(1, posts.Count);

      posts = service.GetByLocation(1, 1, 1);

      Assert.AreEqual(0, posts.Count);
    }
  }
}
