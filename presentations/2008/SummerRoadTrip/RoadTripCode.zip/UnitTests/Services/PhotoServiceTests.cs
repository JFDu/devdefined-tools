﻿using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SummerRoadTrip.Services.Contracts;
using SummerRoadTrip.Services;
using SummerRoadTrip.Model;

namespace SummerRoadTrip.UnitTests.Services
{
  public class PhotoServiceTests : TestFixture
  {
    [TestMethod]
    public void GetPhoto()
    {
      IPhotoService service = new PhotoService();

      Photo photo = service.GetPhoto(1);

      Assert.IsNotNull(photo);
      Assert.AreEqual("Test Photo", photo.Name);

      photo = service.GetPhoto(-1);
      Assert.IsNull(photo);
    }

    [TestMethod]
    public void GetAllPhotos()
    {
      IPhotoService service = new PhotoService();

      List<Photo> photos = service.GetAllPhotos();

      Assert.IsNotNull(photos);
      Assert.AreEqual(5, photos.Count);
    }

    [TestMethod]
    public void GetRandomPhotos()
    {
      IPhotoService service = new PhotoService();

      List<Photo> photos = service.GetRandomPhotos(3);

      Assert.IsNotNull(photos);
      Assert.AreEqual(3, photos.Count);
    }

    [TestMethod, Ignore]
    public void GetByLocation()
    {
      IPhotoService service = new PhotoService();

      List<Photo> photos = service.GetByLocation(1, 1, 1);

      Assert.AreEqual(3, photos.Count);
    }
  }
}
