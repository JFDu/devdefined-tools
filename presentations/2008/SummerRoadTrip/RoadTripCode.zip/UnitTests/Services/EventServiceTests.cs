﻿using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SummerRoadTrip.Services.Contracts;
using SummerRoadTrip.Services;
using SummerRoadTrip.Model;

namespace SummerRoadTrip.UnitTests.Services
{
  public class EventServiceTests : TestFixture
  {   
    [TestMethod]
    public void GetEvents()
    {
      IEventService _service = new EventService();

      List<Event> events = _service.GetEvents();

      Assert.AreEqual(11, events.Count);
    }

    [TestMethod]
    public void GetEvent()
    {
      IEventService service = new EventService();
      Event ev = service.GetEvent(1);

      Assert.IsNotNull(ev);
      Assert.AreEqual(1, ev.Id);
      Assert.AreEqual("Auckland Institute of Technology", ev.LocationName);

      ev = service.GetEvent(-1);

      Assert.IsNull(ev);
    }
  }
}
